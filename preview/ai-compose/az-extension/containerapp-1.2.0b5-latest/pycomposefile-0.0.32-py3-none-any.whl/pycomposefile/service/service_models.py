from ..compose_element import ComposeElement, ComposeStringOrListElement


class Model(ComposeElement):
    """
    Represents a model reference at the service level.
    
    Supports both short and long syntax:
    - Short: my_model (string)
    - Long: my_model: {endpoint_var: MODEL_URL, model_var: MODEL}
    """
    element_keys = {
        "endpoint_var": (str, "https://github.com/compose-spec/compose-spec/blob/master/spec.md#models"),
        "model_var": (str, "https://github.com/compose-spec/compose-spec/blob/master/spec.md#models"),
    }

    def __init__(self, model_definition, key=None, compose_path=""):
        if isinstance(model_definition, str):
            # Short syntax: just a model name reference
            model_definition = {
                "source": model_definition
            }
        super().__init__(model_definition, compose_path)


class ServiceModels(ComposeStringOrListElement):
    """
    Service-level models field that references models from the top-level models section.
    Can be either a list (short syntax) or a mapping (long syntax).
    """
    transform = Model
