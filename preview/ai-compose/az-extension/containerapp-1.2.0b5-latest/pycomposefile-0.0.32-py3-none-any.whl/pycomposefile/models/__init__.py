from ..compose_element import ComposeElement


class Models(ComposeElement):
    """
    Represents a model definition in the top-level models section of a Compose file.
    
    Based on compose-spec models directive (Compose v2.38.0+):
    https://github.com/compose-spec/compose-spec/blob/master/spec.md#models
    
    Models define AI models that services can use at runtime.
    """
    element_keys = {
        "image": (str, ""),  # Model image reference
        "external": (bool, ""),  # Whether model is externally managed
        "name": (str, ""),  # Custom name for the model
    }
